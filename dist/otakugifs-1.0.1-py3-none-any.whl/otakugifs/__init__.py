from .client import OtakuGIFS

__version__ = "0.1.0"
__author__ = "infinite"
__all__ = ["OtakuGIFS"]
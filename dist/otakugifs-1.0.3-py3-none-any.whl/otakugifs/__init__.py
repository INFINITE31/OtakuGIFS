from .client import OtakuGIFS

__version__ = "1.0.3"
__author__ = "infinite"
__all__ = ["OtakuGIFS"]


from .client import OtakuGIFS

__version__ = "1.0.4"
__author__ = "INFINITE_."
__all__ = ["OtakuGIFS"]

